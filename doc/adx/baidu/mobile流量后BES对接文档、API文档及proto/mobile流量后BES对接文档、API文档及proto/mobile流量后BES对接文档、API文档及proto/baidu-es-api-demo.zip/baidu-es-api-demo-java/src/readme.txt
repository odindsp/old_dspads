1. 发布介绍
此客户端库基于Java语言创建。所有的客户端调用类请参考src目录下的源文件，本客户端库旨在提供调用封装以及代理类生成，并不提供客户端 业务逻辑。
使用过程中如果遇到任何问题，请联系es服务的客服人员，发邮件至essupport@baidu.com。


2. 环境配置
请在调用环境中
*确认已安装JDK1.6+版本以上的开发环境
*确认开发环境可以访问互联网，可以尝试ping api.es.baidu.com


3. 使用方式:
1) 填写相关配置
配置在config.properties文件中，请填写
DSPID=userid
TOKEN=token

2) 调用API demo
客户demo类:com.baidu.es.demo.advertiser.APIAdvertiserDemo
创意demo类:com.baidu.es.demo.creative.APICreativeDemo
报告demo类:com.baidu.es.demo.report.APIReportDemo


4. changlog：
2013.5.30 V1 release
