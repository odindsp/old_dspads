/* 
 * File:   price.h
 * Author: weihaibin
 *
 * Created on 2015年12月2日, 下午4:10
 */

#include "base64.h"
#include "hex.h"
#include "hmac_sha1.h"
#include "price.h"

#define TIME_STAMP_LEN  4
#define ENC_PRICE_LEN   8
#define SIG_LEN         4

char* xor_bytes(char* b1,char* b2,size_t len){
    char* ret = malloc(len);
    for (int i = 0; i < len; i++){
        ret[i] = b1[i] ^ b2[i];
    }
    return ret;
}

double price_decode(const char* dec_key,const char* sign_key,const char* src){
    char* q = base64url_decode(src);
    
    char* time_ms_stamp_bytes = malloc(TIME_STAMP_LEN);
    char* enc_price = malloc(ENC_PRICE_LEN);
    char* sig = malloc(SIG_LEN);
    size_t n = 0;
    for (int i = 0; i < TIME_STAMP_LEN; i++){
        time_ms_stamp_bytes[i] = q[n];
        n++;
    }
    for (int i = 0; i < ENC_PRICE_LEN; i++){
        enc_price[i] = q[n];
        n++;
    }
    for (int i = 0; i < SIG_LEN; i++){
        sig[i] = q[n];
        n++;
    }
    
    int dec_key_len;
    unsigned char *dec_key_bytes = hex(dec_key,&dec_key_len);
    unsigned char pad[20];
    hmac_sha1(dec_key_bytes,  dec_key_len,time_ms_stamp_bytes, TIME_STAMP_LEN, pad);  
    unsigned char* dec_price = xor_bytes(pad,enc_price,8);
    double price;
    memcpy(&price,dec_price,8);
    
    //校验
    int sign_key_bytes_len;
    unsigned char* sign_key_bytes = hex(sign_key,&sign_key_bytes_len);
    unsigned char* sign_com_bytes = malloc(ENC_PRICE_LEN+TIME_STAMP_LEN);
    memcpy(sign_com_bytes,dec_price,ENC_PRICE_LEN);
    memcpy(&sign_com_bytes[ENC_PRICE_LEN],time_ms_stamp_bytes,TIME_STAMP_LEN);
    
    unsigned char* osig = malloc(20);
    hmac_sha1(sign_key_bytes,sign_key_bytes_len,sign_com_bytes,ENC_PRICE_LEN+TIME_STAMP_LEN,osig);
    return price;
}


