var crypto = require('crypto');
var Long = require('long');

function encryptPrice(oriPrice, eKey, iKey, iv) {
	if(!eKey || !iKey){
		return 'encrypt fail';
	}
	eKey = new Buffer(eKey, 'hex');
	iKey = new Buffer(iKey, 'hex');
	iv = iv ? iv : crypto.randomBytes(16);
	var pad = crypto.createHmac('sha1', eKey).update(iv).digest().slice(0, 8);
	var price = new Buffer(8);
	price.writeUInt32BE(0, 0);
	price.writeUInt32BE(oriPrice, 4);
	var encPrice = new Buffer(8);
	for (var i = encPrice.length - 1; i >= 0; i--) {
		encPrice[i] = pad[i] ^ price[i];
	}
	var signature = crypto.createHmac('sha1', iKey).update(Buffer.concat([price, iv])).digest().slice(0, 4);
	var finalMessage = Buffer.concat([iv, encPrice, signature]).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/\=/g, '')
	return finalMessage;
}

function decryptPrice(erc, eKey, iKey) {
        eKey = new Buffer(eKey,'hex');
        iKey = new Buffer(iKey,'hex');
        erc = unWebSafeBase64(erc)
        var ercBuffer = new Buffer(erc, 'base64');
        var iv = ercBuffer.slice(0, 16);
        var encodedPrice = ercBuffer.slice(16, 24)
        var sig = ercBuffer.slice(24, 28).toString('hex')
        var pad = crypto.createHmac('sha1', eKey).update(iv).digest()
        var realPriceBuffer = new Buffer(8)
        for (var i = encodedPrice.length - 1; i >= 0; i--) {
            realPriceBuffer[i] = encodedPrice[i] ^ pad[i]
        };
        var high = realPriceBuffer.readUInt32BE(0)
        var low = realPriceBuffer.readUInt32BE(4)
        var realPrice = Long.fromBits(low, high).toNumber();
        var calCrc = crypto.createHmac('sha1', iKey).update(realPriceBuffer).update(iv).digest().slice(0, 4).toString('hex');
        
        if (calCrc == sig) {
            return  realPrice;
        } else {
            return 0;
        }
}


function unWebSafeBase64(wsb64String) {
    var pad = '';
    if ((wsb64String.length % 4) == 2) {
        pad = "==";
    } else if ((wsb64String.length % 4) == 1) {
        pad = "=";
    }
    return wsb64String.replace(/\-/g, '+').replace(/\_/g, '/') + pad;
}

if (!module.parent) {
	var pri = 10000
	var sampleEKey = '96ece829e94aede8d0d66353eedc3b5edd58d4c4aedf134c660b41c677e9bd2d';
	var sampleIKey = 'b7afc2b6b7980d004b3622c6d91d427801c336e20c29b519be56b1c1b40f17ac';
	console.log(encryptPrice(pri, sampleEKey, sampleIKey));

}


exports.decryptPrice = decryptPrice;
exports.encryptPrice = encryptPrice;
// function encryptIds(){

// }