package com.baidu.es.demo.report;

import com.baidu.es.demo.common.BaseHTTP;
import com.baidu.es.demo.common.constant.BaiduEsConstant;
import com.baidu.es.demo.report.vo.APIReportConsumeRequest;
import com.baidu.es.demo.report.vo.APIReportRtbRequest;

public class APIReportDemo extends BaseHTTP {

	public void testReportRtb() {
		APIReportRtbRequest request = new APIReportRtbRequest();
		request.setAuthHeader(getAuthHeader());
		request.setStartDate("2013-05-15");
		request.setEndDate("2013-05-16");
		post(BaiduEsConstant.REPORT_RTB_URL, request);
	}

	public void testReportConsume() {
		APIReportConsumeRequest request = new APIReportConsumeRequest();
		request.setAuthHeader(getAuthHeader());
		request.setStartDate("2013-05-15");
		request.setEndDate("2013-05-16");
		post(BaiduEsConstant.REPORT_CONSUME_URL, request);
	}
	
	public static void main(String[] args) {
		APIReportDemo demo = new APIReportDemo();
		demo.testReportRtb();
		//demo.testReportConsume();
	}

}
