package com.baidu.es.demo.advertiser;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.baidu.es.demo.advertiser.vo.APIAdvertiser;
import com.baidu.es.demo.advertiser.vo.APIAdvertiserAddRequest;
import com.baidu.es.demo.advertiser.vo.APIAdvertiserGetAllRequest;
import com.baidu.es.demo.advertiser.vo.APIAdvertiserGetRequest;
import com.baidu.es.demo.common.BaseHTTP;
import com.baidu.es.demo.common.constant.BaiduEsConstant;

public class APIAdvertiserDemo extends BaseHTTP {

	public void testGetAll() {
		APIAdvertiserGetAllRequest request = new APIAdvertiserGetAllRequest();
		request.setAuthHeader(getAuthHeader());
		request.setStartDate("2013-05-04");
		request.setEndDate("2013-05-21");
		post(BaiduEsConstant.ADVERTISER_GETALL_URL, request);
	}

	public void testGet() {
		APIAdvertiserGetRequest request = new APIAdvertiserGetRequest();
		request.setAuthHeader(getAuthHeader());
		Long[] advertiserIds = new Long[] { 1l, 2l };
		request.setAdvertiserIds(Arrays.asList(advertiserIds));
		post(BaiduEsConstant.ADVERTISER_GET_URL, request);
	}

	public void testQueryQualification() {
		APIAdvertiserGetRequest request = new APIAdvertiserGetRequest();
		request.setAuthHeader(getAuthHeader());
		Long[] advertiserIds = new Long[] { 1l, 2l };
		request.setAdvertiserIds(Arrays.asList(advertiserIds));
		post(BaiduEsConstant.ADVERTISER_QUERY_QUALIFICATION_URL, request);
	}

	public void testAdd() {
		APIAdvertiserAddRequest request = new APIAdvertiserAddRequest();
		request.setAuthHeader(getAuthHeader());
		request.setRequest(getAdvertiserList());
		post(BaiduEsConstant.ADVERTISER_ADD_URL, request);
	}

	private List<APIAdvertiser> getAdvertiserList() {
		List<APIAdvertiser> ret = new ArrayList<APIAdvertiser>();

		APIAdvertiser advertiser = new APIAdvertiser();
		advertiser.setAdvertiserId(10l);
		advertiser.setAdvertiserName("测试客户-10");
		ret.add(advertiser);

		return ret;
	}

	public static void main(String[] args) {
		APIAdvertiserDemo demo = new APIAdvertiserDemo();
		demo.testGetAll();
		//demo.testGet();
		//demo.testQueryQualification();
		//demo.testAdd();
	}

}
