package com.baidu.es.demo.common.constant;

import java.math.BigDecimal;

public class ReportConstants {

	public static BigDecimal doubleToBigDecimal(double dd){
		BigDecimal bd;
		try{
			bd = BigDecimal.valueOf(dd).setScale(4, BigDecimal.ROUND_HALF_UP);
		}catch(Exception e){
			bd = BigDecimal.valueOf(0d);
		}
		return bd;
	}
	
}
