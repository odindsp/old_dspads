#ifndef HEX_H
#define HEX_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

extern int hex2num(unsigned char c);

extern char* hex(const char* str,int *n);

#endif /* HEX_H */

