 dsp对接工具的使用方法：

## 首先安装nodejs环境；

## 在size.json文件中添加支持的广告尺寸；
   **size.json是数组对象，添加多种尺寸如[{"h":100,"w":640}，{"h":50,"w":600}]，h:高度，w:宽度**

## 在命令行中执行 node protobufTester.js http://xxx(请求地址) xx(请求次数) xx(1表示手机端，2表示pc端)；
   **注意参数间有空格,不同请求多次时,每次Bid Request内容不同,为了测得多样化数据**

## 在命令行中打印BidResponse响应的基本信息，主要包括响应时间，响应状态，解析成功与否，seatbid和bidid字段检测；

## 在浏览器中打开exchange-test目录下adm.html，记录所有的BidRequest和对应的BidResponse，以及BidResponse的字段检测信息和adm内容。
    **注意adm.html是动态的，显示每次请求的结果**

## 补充说明一下nurl,iurl和curl占位符,在adm值中相应位置直接返回##CURL##,##IURL##和##NURL##,
   竞价也写成占位符形式##AUCTION_PRICE##.(占位符其实#xxx###和%%xxx%%都可以，但##xx##形式更好)

    iurl是指你们要使用一个独立的追踪广告是否成功展现的服务，iurl就是你们这个地址
    nurl是竞价成功的通知url，我们的方式是在展现的时候做出通知，所以功能和iurl是类似的，我们保留两种是为了兼容性的考虑

## admtype如果返回json格式，那么请写成{"src":"","width":,"height":,"adID":,"type":"", title:"","text":""}这种格式（文字广告的话，会有title和text部分）