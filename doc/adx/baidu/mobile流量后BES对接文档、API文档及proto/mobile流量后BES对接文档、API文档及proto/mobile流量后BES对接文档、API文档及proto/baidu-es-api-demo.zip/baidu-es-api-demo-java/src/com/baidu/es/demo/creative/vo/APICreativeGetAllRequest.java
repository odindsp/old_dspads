package com.baidu.es.demo.creative.vo;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.baidu.es.demo.common.vo.BaseRequest;

public class APICreativeGetAllRequest extends BaseRequest implements Serializable{

	private static final long serialVersionUID = -2343946895763933471L;

	private String startDate;

	private String endDate;

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	
	public String toString(){
		return new ToStringBuilder(this, ToStringStyle.DEFAULT_STYLE)
		.append("authHeader",authHeader)
		.append("startDate",startDate)
		.append("endDate",endDate)
        .toString();
	}

}
