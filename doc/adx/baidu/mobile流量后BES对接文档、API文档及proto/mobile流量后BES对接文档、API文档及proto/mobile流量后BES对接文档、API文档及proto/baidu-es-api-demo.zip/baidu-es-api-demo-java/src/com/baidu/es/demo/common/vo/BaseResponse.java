package com.baidu.es.demo.common.vo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/**
 * 
 * 基础返回类
 *
 * @author <a href="mailto:zhangxu04@baidu.com">Zhang Xu</a>
 * @version 2013-5-6 下午2:06:06
 * @param <E>
 */
public class BaseResponse implements Serializable {

	private static final long serialVersionUID = -7960520888374886506L;
	
	protected int status = 0;
	
	protected List<APIError> errors = new ArrayList<APIError>();

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public List<APIError> getErrors() {
		return errors;
	}

	public void setErrors(List<APIError> errors) {
		this.errors = errors;
	}
	
	public String toString(){
		return new ToStringBuilder(this, ToStringStyle.DEFAULT_STYLE)
		.append("status",status)
		.append("errors",errors)
        .toString();
	}
	
}
