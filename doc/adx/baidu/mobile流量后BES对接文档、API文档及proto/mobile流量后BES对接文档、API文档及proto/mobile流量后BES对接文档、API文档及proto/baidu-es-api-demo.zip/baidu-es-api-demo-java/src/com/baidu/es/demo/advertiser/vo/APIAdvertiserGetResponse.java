package com.baidu.es.demo.advertiser.vo;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.baidu.es.demo.common.vo.BaseResponse;

public class APIAdvertiserGetResponse extends BaseResponse implements Serializable{

	private static final long serialVersionUID = 1478235016347130580L;

	private List<APIAdvertiser> response;

	public List<APIAdvertiser> getResponse() {
		return response;
	}

	public void setResponse(List<APIAdvertiser> response) {
		this.response = response;
	}
	
	public String toString(){
		return new ToStringBuilder(this, ToStringStyle.DEFAULT_STYLE)
		.append("status",status)
		.append("errors",errors)
		.append("response",response)
        .toString();
	}
}
