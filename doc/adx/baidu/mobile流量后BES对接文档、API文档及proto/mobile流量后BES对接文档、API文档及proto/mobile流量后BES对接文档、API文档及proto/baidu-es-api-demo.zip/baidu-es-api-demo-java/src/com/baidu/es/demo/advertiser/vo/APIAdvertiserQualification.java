package com.baidu.es.demo.advertiser.vo;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

public class APIAdvertiserQualification implements Serializable {
	
	private static final long serialVersionUID = -5834585291032230658L;

	private long advertiserId;

	private int state;

	private List<String> refuseReason;

	public long getAdvertiserId() {
		return advertiserId;
	}

	public void setAdvertiserId(long advertiserId) {
		this.advertiserId = advertiserId;
	}

	public int getState() {
		return state;
	}

	public void setState(int state) {
		this.state = state;
	}

	public List<String> getRefuseReason() {
		return refuseReason;
	}

	public void setRefuseReason(List<String> refuseReason) {
		this.refuseReason = refuseReason;
	}
	
	public String toString(){
		return new ToStringBuilder(this, ToStringStyle.DEFAULT_STYLE)
		.append("advertiserId",advertiserId)
		.append("state",state)
		.append("refuseReason",refuseReason)
        .toString();
	}

}
