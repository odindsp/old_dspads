var  fs = require('fs'),
    iconv = require('iconv-lite'),// 加载编码转换模块
    openDB = require('json-file-db'),
    path = require('path'),
    _= require('lodash'),
    validate = require('validate-url'),
    util = require('util'),
    async  = require('async');

var file = path.join(__dirname,'./result.text');
var logs = openDB(path.join(__dirname,  './log.json'));
exports.analyse= writeFile(file,function(){
    readFile(file);
});


function checkProperty(property,subpro,type){
    var flag=true;
    if(!property){
        return "\r\n没有返回"+subpro;
    }else{
        if(type == "string"){
            if(!_.isString(property)){
                flag =false;
            }
        }else if(type =="float"){
            if(!_.isNumber(property)){
                flag = false;
            }
        }else if(type == "integer"){
            if(!_.isNumber(property)){
                flag = false;
            }
        }
    }
    if(!flag){
        return '\r\n'+subpro+'格式不正确';
    }else{
        return ;
    }
}

function checkurl(property,subpro){
    var flag = true;
    if(!property){
        return "\r\n没有返回"+subpro;
    }else{
        if(!validate(property)){
            flag = false;
        }
    }
    if(!flag){
        return "\r\n"+subpro+"无效";
    }else{
        return ;
    }
}
function writeFile(file,cb){
    //analyse the loig.josn and write the concolusion
    logs.get(function(err,data){
        if(err){
            console.error('读取log.json文件失败',err);
        }else{
            if(data.error){
                var str = "返回"+JSON.stringify(data.error);
            }else{
                var falsenum= _.countBy(data[data.length-1].status,function(n){return  n == 200})['false'],
                    falselist=_.intersection(_.filter(data[data.length-1].status, function(n){
                        return n !=200}));
                var str = "共请求"+"\033[31m"+data.length+"\033[39m"+"次，成功响应"+"\033[31m"+(data.length -(falsenum ? falsenum:0))+"\033[39m"+"次";
                if(falselist.length){
                    str += "\r\n返回状态"+"\033[31m"+falselist+"\033[39m";
                }

                if(data[data.length-1].errids.length !=0){
                    str +="\r\n"+data[data.length-1].errids.length+"次响应与请求id不同";
                }
                if(data[data.length-1].decodeerr !==0){
                    str += "\r\n解析失败的次数:"+"\033[31m"+data[data.length-1].decodeerr+"\033[39m";
                }else{
                    str += "\r\n解析成功";
                }
                var seatpar= 0,bididf=0,bididtype= 0,renderstr= "",admhtmlstr ="",sibidflag =true;

                for(var m in data){
                    var statucode,bidObjid="",bidObjimpid="",bidObjprice="",bridObadomain = "",bidObjw ="",seatObj="",
                        bidObjh ="",bidObjtype ="",bidObjbundle = true,bidObjadid = true,bidObjcid =true,bidObjcrid = true,bidObadm = "",
                        bidObiurl="",bidObnurl =true,bidObcurl="",bidObjextiurl = "",bidObjcat = "",bidObjattr="",seatbidparm=true,
                        admType ='',action='',process_time='',admflag=true,admflag2=true;
                    var dataobj = data[m];
                    statucode = dataobj['status'][m];
                    var logobjstr= "<font color=\"#ff1a4b\">",fieldstr="";
                    if(dataobj.response['seatbid'] && dataobj.response['seatbid'].length !== 0){
                        var setabidArr = dataobj.response['seatbid'];
                        if(!(setabidArr instanceof  Array)){
                            seatpar++;
                        }else{
                            if(setabidArr.length > 0){

                                for(var i in setabidArr){

                                    var setabidObj = setabidArr[i];
                                    var bidArr = setabidObj.bid;
                                    var seat =setabidObj.seat;
                                    if(checkProperty(seat,'seat','string')){
                                        logobjstr += checkProperty(seat,'seat','string');
                                    }
                                    for(var i in bidArr){
                                        var admstr='';
                                        var bidObj = bidArr[i];
                                        if(checkProperty(bidObj.id,'bid值中id','string')){
                                            logobjstr += checkProperty(bidObj.id,'bid值中id','string');
                                        }
                                        if(checkProperty(bidObj.impid,'impid','string')){
                                            logobjstr += checkProperty(bidObj.impid,'impid','string');
                                        }
                                        if(checkProperty(bidObj.price,'price','float')){
                                            logobjstr += checkProperty(bidObj.price,'price','float');
                                        }
                                        if(checkProperty(bidObj.adomain,'adomain','string')){
                                            logobjstr += checkProperty(bidObj.adomain,'adomain','string');
                                        }
                                        if(checkProperty(bidObj.w,'w','float')){
                                            logobjstr += checkProperty(bidObj.w,'w','float');
                                        }
                                        if(checkProperty(bidObj.h,'h','float')){
                                            logobjstr += checkProperty(bidObj.h,'h','float');
                                        }
                                        if(checkProperty(bidObj.type,'type','float')){
                                            logobjstr += checkProperty(bidObj.type,'type','float');
                                        }
                                        if(checkProperty(bidObj.admtype,'admtype','integer')){
                                            logobjstr += checkProperty(bidObj.admtype,'admtype','integer');
                                        }

                                        if(bidObj.bundle){
                                            if(!_.isString(bidObj.bundle)){
                                                logobjstr += "\r\n" + 'bundle格式不正确';
                                            }

                                        }
                                        if(bidObj.adid){
                                            if(!_.isString(bidObj.adid)){
                                                logobjstr += "\r\n" + 'adid格式不正确';
                                            }
                                        }
                                        if(bidObj.cid){
                                            if(!_.isString(bidObj.cid)){
                                                logobjstr += "\r\n" + 'cid格式不正确'
                                            }
                                        }
                                        if(bidObj.crid){
                                            if(!_.isString(bidObj.crid)){
                                                logobjstr += "\r\n" + 'crid格式不正确'
                                            }
                                        }
                                        if(bidObj.adm){

                                            if(bidObj.admtype === 1){//JSON (protobuf解析可能是整数或字符串，这里用==)
                                                try{
                                                    admstr += bidObj.adm;
                                                    var bidobjjson= JSON.parse(bidObj.adm);
                                                }catch(e){
                                                    logobjstr += '\r\nadmtype与adm格式不匹配';
                                                }
                                            }else if(bidObj.admtype === 2){//HTML
                                                try{
                                                    var admtest = JSON.parse(bidObj.adm);
                                                    logobjstr += '\r\nadmtpye和adm格式不匹配';
                                                }catch(err){
                                                    var replacestring ='';

                                                    if(/##CURL##/.test(bidObj.adm)){

                                                        replacestring = bidObj.adm.replace(/##CURL##/g, bidObj.curl);
                                                    }else{
                                                        logobjstr += '\r\n adm中没有返回curl占位符'
                                                    }
                                                    if(/##IURL##/.test(bidObj.adm) && bidObj.iurl !== null){
                                                        replacestring = replacestring.replace(/##IURL##/g, bidObj.iurl);
                                                    }else{
                                                        logobjstr += '\r\n adm中没有返回iurl占位符'
                                                    }
                                                    if(/##NURL##/.test(bidObj.adm) && bidObj.nurl !== null){
                                                        replacestring = replacestring.replace(/##NURL##/g, bidObj.nurl);
                                                    }else if(/AUCTION_PRICE/.test(bidObj.nurl)){
                                                        logobjstr += '\r\n adm中没有返回nurl占位符'
                                                    }

                                                    //  console.log('replace===',replacestring);
                                                 /*   var replacestring =   bidObj.adm.replace(/##CURL##/g, bidObj.curl);
                                                    replacestring =replacestring.replace(/##IURL##/g,bidObj.iurl);
                                                    replacestring = replacestring.replace(/##NURL##/g,bidObj.nurl);*/
                                                    admstr += replacestring;
                                                }
                                            }
                                            bidObj.adm = admstr;
                                        }else{
                                            logobjstr +='\r\nadm没有返回';
                                        }
                                        if(checkurl(bidObj.iurl,'iurl')){
                                            logobjstr += checkurl(bidObj.iurl,'iurl');
                                        }
                                        if(bidObj.nurl){
                                            if(!validate(bidObj.nurl)){
                                                logobjstr +="\r\n"+'nurl无效';
                                            }
                                        }
                                        if(checkurl(bidObj.curl,'curl')){
                                            logobjstr += checkurl(bidObj.curl,'curl');
                                        }
                                        if(bidObj.extiurl){
                                            for(var j in bidObj.extiurl){
                                                var extiurlObj = bidObj.extiurl[j];

                                                if(extiurlObj && !validate(extiurlObj)){
                                                    logobjstr  += "\r\n extiurl无效";
                                                }else if(!extiurlObj){
                                                    logobjstr  += "\r\n warning: extiurl请返回空数组"
                                                }
                                            }
                                        }
                                        if(bidObj.cat){
                                            _.isNumber(bidObj.cat) ? '': logobjstr += '\r\ncat格式不正确'
                                        }
                                        if(bidObj.attr){
                                            _.isNumber(bidObj.attr) ? '': logobjstr += '\r\nattr格式不正确'
                                        }
                                        if(bidObj.action && ["click","install"].indexOf(bidObj.action) === -1){
                                            logobjstr += '\r\naction返回错误'
                                        }

                                    }
                                }
                            }else{
                                logobjstr += "\r\n warning:seatbid返回空! "
                            }
                        }
                    }else{
                        logobjstr +="\r\n seatbid返回空";
                        sibidflag = false;
                    }
                    if(!dataobj.response.bidid){
                        bididf ++;
                    }else{
                        if(!_.isString(dataobj.response.bidid)){
                            bididtype ++;
                        }
                    }
                    if(dataobj.response.nbr){
                        _.isNumber(dataobj.response.nbr)? '': logobjstr += "\r\nnbr格式不正确"
                    }
                    if(dataobj.response.process_time && !_.isNumber(dataobj.response.process_time)){
                        logobjstr += '\r\nprocess_time格式不正确';
                    }
                    logobjstr += "</font>"
                    if(logobjstr.indexOf('\r\n')  === -1){
                        logobjstr += "<font color=\"#ff1a4b\">"+"\r\n 字段格式无误" +"</font>"
                    }
                    fieldstr += "<li>";
                    fieldstr += "<h2>Bid Request</h2>" + "<pre>" + util.inspect(dataobj['request'],{depth:4}) + "</pre>";
                   /* if(dataobj['response']['seatbid'][0] && dataobj['response']['seatbid'][0]['bid'] && dataobj['response']['seatbid'][0]['bid'][0] && dataobj['response']['seatbid'][0]['bid'][0]['adm']){
                        dataobj['response']['seatbid'][0]['bid'][0]['adm'] =
                    }*/
                    /*for(var i=0;i<dataobj['response']['seatbid'].length;i++){
                        var seatObject = dataobj['response']['seatbid'][i];
                        for(var j =0;j < seatObject['bid'].length; j++){
                            var bidObject = seatObject['bid'][j];
                            bidObject['adm'] = admstr || '';
                        }
                    }*/
                    fieldstr += "<h2>Bid Response</h2>" +"<pre>" +util.inspect(dataobj['response'],{depth:4})+"</pre>";
                    fieldstr += "<h2>StautCode</h2>" +"<pre>" +statucode +"</pre>"
                    fieldstr += "<h3>字段检测</h3>"+"<pre>"+logobjstr+"</pre>";
                   // fieldstr += "<h3>adm内容</h3>"+"<pre>"+(admstr? admstr:"<font color=\"#ff1a4b\">没有返回adm</font>")+"</pre>" ;
                    fieldstr += "</li>";
                    renderstr += fieldstr;
                }

                if(seatpar){
                    str +="\r\n"+"\033[31m"+seatpar+"\033[39m"+"次seatbid值格式不正确";
                }
                if(bididf){
                    str +="\r\n"+"\033[31m"+bididf+"\033[39m"+"次bidid返回空"
                }
                if(bididtype){
                    str +="\r\n"+bididtype+"次bidid值格式不正确"
                }
                if(!sibidflag){
                    str +="\r\n有seatbid返回空";
                }

            }
            admhtmlstr +="<html> <head> <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\"><title>Rendered snippets</title> </head> <body id='viewer'><h1>Rendered Snippets</h1> <p>Your server has returned the following renderable snippets:</p> <ul>";
            admhtmlstr += renderstr;
            admhtmlstr += " </ul></body></html>";
            sisplayadm(admhtmlstr);
            var arr =iconv.encode(str,'utf8');
            fs.writeFile(file, arr,function(err){
                if(err){
                    console.error('从log.json写进result.text失败',err);
                }else{
                    cb();
                }
            });
        }
    })
}

function readFile(file){
    fs.readFile(file, function(err, data){
        if(err)
            console.log("读取文件fail " + err);
        else{
            // 读取成功时  
            // 输出字节数组  
            // 把数组转换为gbk中文
            var str = iconv.decode(data, 'utf8');
            console.log('\033[36m BidResponse检查结果:\033[39m'+'\r\n'+str);
        }
    });
}

function sisplayadm(adminfo){
    fs.open("adm.html","w+",function(err,fd){
        //var buf = " <!DOCTYPE html> <html lang=\"en\"> <head> <meta charset=\"UTF-8\"> <title>adm展示测试</title> </head> <body> <div id=\"mydiv\"></div> </body> <script type=\"text/javascript\">document.getElementById(\"mydiv\").innerHTML =' "+admstr +"'</script> </html>";
        var buf = adminfo;
        var c = fs.write(fd,buf);

    })
}

