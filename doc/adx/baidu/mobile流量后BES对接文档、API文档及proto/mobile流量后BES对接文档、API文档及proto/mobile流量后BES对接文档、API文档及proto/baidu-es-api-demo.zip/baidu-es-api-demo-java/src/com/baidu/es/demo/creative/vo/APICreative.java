package com.baidu.es.demo.creative.vo;

import java.io.Serializable;
import java.util.List;

public class APICreative implements Serializable {

	private static final long serialVersionUID = -6226226595436014584L;

	private int type = -1;

	private String creativeUrl;

	private String targetUrl;

	private String landingPage;

	private List<String> monitorUrls;

	private int height;

	private int width;

	private long creativeId;

	private int creativeTradeId;

	private int state;

	private long advertiserId;

	private byte[] binaryData;

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public String getCreativeUrl() {
		return creativeUrl;
	}

	public void setCreativeUrl(String creativeUrl) {
		this.creativeUrl = creativeUrl;
	}

	public String getTargetUrl() {
		return targetUrl;
	}

	public void setTargetUrl(String targetUrl) {
		this.targetUrl = targetUrl;
	}

	public String getLandingPage() {
		return landingPage;
	}

	public void setLandingPage(String landingPage) {
		this.landingPage = landingPage;
	}

	public List<String> getMonitorUrls() {
		return monitorUrls;
	}

	public void setMonitorUrls(List<String> monitorUrls) {
		this.monitorUrls = monitorUrls;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public long getCreativeId() {
		return creativeId;
	}

	public void setCreativeId(long creativeId) {
		this.creativeId = creativeId;
	}

	public int getCreativeTradeId() {
		return creativeTradeId;
	}

	public void setCreativeTradeId(int creativeTradeId) {
		this.creativeTradeId = creativeTradeId;
	}

	public int getState() {
		return state;
	}

	public void setState(int state) {
		this.state = state;
	}

	public long getAdvertiserId() {
		return advertiserId;
	}

	public void setAdvertiserId(long advertiserId) {
		this.advertiserId = advertiserId;
	}

	public byte[] getBinaryData() {
		return binaryData;
	}

	public void setBinaryData(byte[] binaryData) {
		this.binaryData = binaryData;
	}

}
