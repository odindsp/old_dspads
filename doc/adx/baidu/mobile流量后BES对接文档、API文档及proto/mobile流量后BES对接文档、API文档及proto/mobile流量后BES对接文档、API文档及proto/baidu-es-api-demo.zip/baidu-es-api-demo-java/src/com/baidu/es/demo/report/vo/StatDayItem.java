package com.baidu.es.demo.report.vo;

import java.io.Serializable;
import java.math.BigDecimal;

import com.baidu.es.demo.common.constant.ReportConstants;
import com.baidu.es.demo.util.ReportUtil;

public class StatDayItem  implements Serializable {

	private static final long serialVersionUID = -4577961739347985759L;
	
	/**
	 * 基础统计数据
	 */
	private String showDate;
	protected long srchs;//展现
	protected long clks;//点击
	protected double cost;//单位元
	protected BigDecimal ctr;//点击率
	protected BigDecimal acp;//平均点击价格
	protected BigDecimal cpm;//千次展现成本

	public void fillZeroStat() {
		this.srchs = 0;
		this.clks = 0;
		this.cost = 0;
		this.ctr = BigDecimal.valueOf(-1);
		this.acp = BigDecimal.valueOf(-1);
		this.cpm = BigDecimal.valueOf(-1);
	}

	public BigDecimal getAcp() {
		return acp;
	}

	public void setAcp(double acp) {
		if ((acp > 0) && (acp < 0.01))
			acp = 0.01;
		this.acp = ReportConstants.doubleToBigDecimal(acp);
	}

	public long getClks() {
		return clks;
	}

	public void setClks(long clks) {
		this.clks = clks;
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}

	public BigDecimal getCpm() {
		return cpm;
	}

	public void setCpm(double cpm) {
		this.cpm = ReportUtil.doubleToBigDecimal(cpm);
	}

	public BigDecimal getCtr() {
		return ctr;
	}

	public void setCtr(double ctr) {
		this.ctr = ReportUtil.doubleToBigDecimal(ctr);
	}

	public long getSrchs() {
		return srchs;
	}

	public void setSrchs(long srchs) {
		this.srchs = srchs;
	}

	public void setCtr(BigDecimal ctr) {
		this.ctr = ctr;
	}

	public void setAcp(BigDecimal acp) {
		this.acp = acp;
	}

	public void setCpm(BigDecimal cpm) {
		this.cpm = cpm;
	}

	public String getShowDate() {
		return showDate;
	}

	public void setShowDate(String showDate) {
		this.showDate = showDate;
	}

}
