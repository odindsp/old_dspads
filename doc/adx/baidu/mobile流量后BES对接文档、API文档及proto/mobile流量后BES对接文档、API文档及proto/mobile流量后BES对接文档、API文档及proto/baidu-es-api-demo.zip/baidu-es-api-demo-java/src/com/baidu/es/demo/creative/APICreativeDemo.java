package com.baidu.es.demo.creative;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.baidu.es.demo.common.BaseHTTP;
import com.baidu.es.demo.common.constant.BaiduEsConstant;
import com.baidu.es.demo.creative.vo.APICreative;
import com.baidu.es.demo.creative.vo.APICreativeAddRequest;
import com.baidu.es.demo.creative.vo.APICreativeGetAllRequest;
import com.baidu.es.demo.creative.vo.APICreativeGetRequest;
import com.baidu.es.demo.creative.vo.APICreativeUpdateRequest;
import com.baidu.es.demo.util.ImageUtil;

public class APICreativeDemo extends BaseHTTP {

	public void testGetAll() {
		APICreativeGetAllRequest request = new APICreativeGetAllRequest();
		request.setAuthHeader(getAuthHeader());
		request.setStartDate("2013-05-21");
		request.setEndDate("2013-05-21");
		post(BaiduEsConstant.CREATIVE_GETALL_URL, request);
	}

	public void testGet() {
		APICreativeGetRequest request = new APICreativeGetRequest();
		request.setAuthHeader(getAuthHeader());
		Long[] creativeIds = new Long[] { 1l, 2l };
		request.setCreativeIds(Arrays.asList(creativeIds));
		post(BaiduEsConstant.CREATIVE_GET_URL, request);
	}

	public void testQueryAuditState() {
		APICreativeGetRequest request = new APICreativeGetRequest();
		request.setAuthHeader(getAuthHeader());
		Long[] creativeIds = new Long[] { 1l, 2l };
		request.setCreativeIds(Arrays.asList(creativeIds));
		post(BaiduEsConstant.CREATIVE_QUERY_AUDIT_STATE_URL, request);
	}

	public void testAdd() {
		APICreativeAddRequest request = new APICreativeAddRequest();
		request.setAuthHeader(getAuthHeader());
		request.setRequest(getCreativeList());
		post(BaiduEsConstant.CREATIVE_ADD_URL, request);
	}
	
	public void testUpdate() {
		APICreativeUpdateRequest request = new APICreativeUpdateRequest();
		request.setAuthHeader(getAuthHeader());
		request.setRequest(getCreativeList());
		post(BaiduEsConstant.CREATIVE_UPDATE_URL, request);
	}

	private List<APICreative> getCreativeList() {
		List<APICreative> ret = new ArrayList<APICreative>();

		APICreative creative = new APICreative();
		creative.setAdvertiserId(1l);
		creative.setCreativeId(1l);
		creative.setCreativeTradeId(190302);
		//creative.setCreativeUrl("http://10.46.126.52:8501/media/v1/06000akFCTVxcBmq1UIj6HSwQkaIjHc.swf");
		creative.setLandingPage("http://landingpage.com9999/");
		List<String> monitorUrls = new ArrayList<String>();
		monitorUrls.add("http://monitorurl.com99999/");
		creative.setMonitorUrls(monitorUrls);
		creative.setTargetUrl("http://targeturl.com9999/");
		ret.add(creative);

		fillImage(creative);

		return ret;
	}

	private void fillImage(APICreative creative) {
		creative.setBinaryData(ImageUtil.GetImageByte(getImageFilePath("960_90.jpg")));
		creative.setHeight(90);
		creative.setWidth(960);
		creative.setType(1);
	}

	private String getImageFilePath(String fileName) {
		return new File("").getAbsolutePath() + "/image/" + fileName;
	}
	
	public static void main(String[] args) {
		APICreativeDemo demo = new APICreativeDemo();
		//demo.testGetAll();
		//demo.testGet();
		//demo.testQueryAuditState();
		//demo.testAdd();
		demo.testUpdate();
	}

}
