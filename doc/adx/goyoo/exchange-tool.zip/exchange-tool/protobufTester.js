var   http = require('http'),
	protobuf = require('protobufjs'),
	path = require('path'),
	async= require('async'),
	util= require('util'),
	request= require('request'),
	Q=  require('q'),
	fs = require('fs'),
	_ =  require('lodash'),
	url  = require('url'),
	openDB = require('json-file-db');
var bidRequestBuilder = protobuf.loadProtoFile(path.join(__dirname, 'openrtb.proto')).build('BidRequest');
var bidResponseBuilder = protobuf.loadProtoFile(path.join(__dirname, 'openrtb.proto')).build('BidResponse');
var logs = openDB(path.join(__dirname,  './log.json')),
	sizejson = openDB(path.join(__dirname, './size.json'));

var  start = Date.now();
var urlstring= url.format(process.argv.slice(2).toString().trim());
var urlObj = url.parse(process.argv.slice(2).toString().trim());

var ip = urlObj.host,
	urlpath = urlObj.path.split(',')[0],
	times = urlObj.path.charAt(urlObj.path.lastIndexOf(',')-1),
	type = urlObj.path.substring(urlObj.path.lastIndexOf(',')+1);

var domainstr= urlstring.split('//')[1].split('/')[0];
var reg = new RegExp("^[0-9a-zA-Z]+[0-9a-zA-Z\.-]*\.[a-zA-Z]{2,4}$","i");
if(!reg.test(domainstr)){
	try{
		var port = (urlstring.split('//')[1].split('/')[0].split(':')[1].trim()) ;
	}catch(err){
		process.stdout.write('\033[31m error:没有获取到端口参数! \033[39m');
	}
}
console.log('\033[36m请求参数\033[39m：\n'+'ip:',ip,'urlpath:',urlpath,'type:',type,'times:',times);

var options = {
	host: ip,
	port: 80,
	headers: {
		'Content-Type': 'application/x-protobuf',
		'timeout':500
	},
	method: 'POST',
	path:urlpath ||''
}
var errtimes = 0;
var requestObj;

function asyrequest(cb){
	var testRequest ={};
	function insertimp(){
		var deferred = Q.defer();
		var impArray = [];
		sizejson.get(function(err,data){
			//取size.json中数组随机数
			data = _.pullAt(data,Math.floor(Math.random()*(data.length)));
			for(var i in data){
				var sizeObj = data[i];
				var impObj={};
				impObj['id'] = (parseInt(i)+1).toString();
				//impObj['bidfloor'] = ~~Math.floor(Math.random() * 1000);
				impObj['bidfloor'] = 0;
				impObj['banner'] ={};
				impObj['banner']['id'] =(parseInt(i)+1).toString();
				impObj['banner']['h'] = parseInt(sizeObj.h);
				impObj['banner']['w'] = parseInt(sizeObj.w);
				//	impObj['banner']['wtype'] = _.pullAt([1,2,3,4],Math.floor(Math.random()*([1,2,3,4].length))) ;
				//	impObj['banner']['btype'] = _.pullAt([1,2,3,4],Math.floor(Math.random()*([1,2,3,4].length))) ;
				impObj['banner']['battr'] = _.pullAt(["706","70601","70602","70603","70699","711","71101","71102","71112","71113","72003"],Math.floor(Math.random()* (["706","70601","70602","70603","70699","711","71101","71102","71112","71113","72003"].length)));
				//impObj['banner']['pos'] = parseInt(_.pullAt([0,1,2,3,4,5,6,7],Math.floor(Math.random()*([0,1,2,3,4,5,6,7].length))).toString());
				impObj['banner']['keywords'] = ["ab"];
				impObj['banner']['bwords'] = ["cd"];
				impArray.push(impObj);
			}
			deferred.resolve(impArray);
		});
		return deferred.promise;
	}

	insertimp().then(function(data){
		testRequest = {
			"id": Math.random().toString(36).substr(2),
			"at": Math.floor(Math.random()*10),
			"tmax": Math.floor(Math.random()*1000),
			// 'test': 0
			"imp": data,
			"site": {
				"id": "102855",
				"domain": "www.foobar.com",
				"cat": ["80206"],
				"page": "http://www.foobar.com/1234.html",
				"publisher": {
					"id": "8953",
					"name": "foobar.com",
					"cat": ["80207"],
					"domain": "foobar.com"
				}
			},
			"app": {
				"id": "agltb3B1Yi1pbmNyDAsSA0FwcBiJkfIUDA",
				"name": "Yahoo Weather",
				"bundle": "com.yahoo.wxapp",
				"paid":23,
				"storeurl": "https://itunes.apple.com/id628677149",
				"publisher": {
					"id": "agltb3B1Yi1pbmNyDAsSA0FwcBiJkfTUCV",
					"name": "yahoo",
					"domain": "www.yahoo.com"
				}
			},
			"device": {
				"h": 1280,
				"w": 800,
				"devicetype": +type,
				"ua": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_6_8) AppleWebKit/537.13(KHTML, like Gecko) Version/5.1.7 Safari/534.57.2",
				"ip": "123.145.167.10"
			},
			"user": {
				"id": "5538d86c5630b40000c09c61"
			},
			"scenario":{
				"type":parseInt(_.pullAt([1,2,3,4],Math.floor(Math.random()*([1,2,3,4].length))).toString())
			}
		};
		if(type === "1"){ //Mobile
			delete testRequest['site']
		}else if(type ==="2"){  //pc
			delete testRequest["app"]
		}
		return testRequest;
	}).then(function(testRequest){
		requestObj = new bidRequestBuilder(testRequest).toBuffer();
		var request = http.request(options);
		request.setNoDelay(true);
		var obj={
			request: testRequest,
			requesttimes: times,
			status: statusarr
		};

		 request.on('error', function(error) {
		 errtimes ++;
		 options.headers['Content-Length'] = requestObj.length;
		 request.useChunkedEncodingByDefault = false;
		 request.chunkedEncoding = false;
		 asyrequest(cb);
		 if(errtimes == parseInt(times-0+1)){
		 cb({error:error}).then(function(result){
		 var analysislog= require('./logAnaysis2.js');
		 analysislog.analyse();
		 }).catch(function(err){
		 console.err(err);
		 }).done();
		 }
		 });

		request.on('response', function(client) {
			var buffers = [];
			statusarr.push(client.statusCode);

			client.on('data', function(chunk) {
				buffers.push(chunk);
			});
			client.on('end', function(callback) {
				var result = Buffer.concat(buffers);

				try{
					result = bidResponseBuilder.decode(result);
					//console.log('-------', util.inspect(result,{depth:5}));
					if(result.id !== testRequest.id || !result.id){
						result.id = result.id||"";
						responseidarr.push(result.id);
					}
				}
				catch(err){
					var bufferstr = result.toString();
					result ="解析失败,请检查是否按照protobuf协议加密，以下是返回结果:\r\n"+bufferstr;
					decodeerr ++;

				}
				obj.errids= responseidarr;
				obj.decodeerr = decodeerr;
				obj.response = result;
				logarr.push(obj);
				if(logarr.length==times){
					//写进log.josn后，执行logAnaysis.js中analyse方法（分析log.json，把结果写进result.test,并读出）
					cb(logarr).then(function(result){
						var analysislog= require('./logAnaysis2.js');
						analysislog.analyse;
						var end = Date.now();
						var elapsed = (end - start) / 1000;
						console.log('共'+elapsed+'s');
					}).catch(function(err){
						console.err(err);
					}).done();
				}
			});
		});
		request.write(requestObj);
		request.end();
	}).done();




}
var logarr= [],statusarr=[],responseidarr=[], decodeerr = 0;

var execfun =function(){
	for(var i=0;i<times; i++){
		(function(par){
			asyrequest(function(obj){
				var deferred = Q.defer();
				var objstr;
				try{
					objstr = JSON.stringify(obj);
				}catch(err){
					objstr = JSON.stringify({error:'返回内容错误'});
				}
				fs.writeFile('./log.json',objstr,function(err){
					if(err){
						console.log('写进lon.json文件错误',err);
						deferred.reject(err);
					}else{
						deferred.resolve('ok');
					}
				});
				return deferred.promise;
			});
		})(i)
	}
}
execfun();

process.on('uncaughtException', function(err) {
	console.error('Caught exception: ' + err.message);
})