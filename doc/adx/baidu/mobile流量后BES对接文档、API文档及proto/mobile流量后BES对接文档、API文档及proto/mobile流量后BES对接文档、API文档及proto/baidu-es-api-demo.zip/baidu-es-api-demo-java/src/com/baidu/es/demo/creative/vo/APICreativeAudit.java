package com.baidu.es.demo.creative.vo;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

public class APICreativeAudit implements Serializable {

	private static final long serialVersionUID = -6226226595436014584L;

	private long creativeId;

	private int state;

	private List<String> refuseReason;

	public long getCreativeId() {
		return creativeId;
	}

	public void setCreativeId(long creativeId) {
		this.creativeId = creativeId;
	}

	public int getState() {
		return state;
	}

	public void setState(int state) {
		this.state = state;
	}

	public List<String> getRefuseReason() {
		return refuseReason;
	}

	public void setRefuseReason(List<String> refuseReason) {
		this.refuseReason = refuseReason;
	}
	
	public String toString(){
		return new ToStringBuilder(this, ToStringStyle.DEFAULT_STYLE)
		.append("creativeId",creativeId)
		.append("state",state)
		.append("refuseReason",refuseReason)
        .toString();
	}

}
