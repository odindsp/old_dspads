package com.baidu.es.demo.report.vo;

import java.io.Serializable;
import java.math.BigDecimal;

import com.baidu.es.demo.util.ReportUtil;

public class MonitorItem implements Serializable {

	private static final long serialVersionUID = -9013530629047529195L;

	/**
	 * 显示时间
	 */
	private String showDate;

	/**
	 * 可发送pv
	 */
	private long availablePv;

	/**
	 * 实际发送pv
	 */
	private long actualPv;

	/**
	 * 参与竞价数
	 */
	private long competePv;

	/**
	 * 竞价成功数
	 */
	private long successPv;

	/**
	 * 放弃竞价数
	 */
	private long giveUpPv;

	/**
	 * 响应超时数
	 */
	private long overtimePv;

	/**
	 * 解析错误数
	 */
	private long parseErrorPv;

	/**
	 * 无效竞价数
	 */
	private long invalidPv;

	/**
	 * 竞价失败数
	 */
	private long failPv;

	/**
	 * 实际发送率
	 */
	private BigDecimal actualRate;

	/**
	 * 参与竞价率
	 */
	private BigDecimal competeRate;

	/**
	 *竞价成功率 
	 */
	private BigDecimal successRate;

	/**
	 * 响应超时率
	 */
	private BigDecimal overtimeRate;

	/**
	 * 解析错误率
	 */
	private BigDecimal parseErrRate;

	public void fillZeroStat() {
		this.availablePv = 0;
		this.actualPv = 0;
		this.competePv = 0;
		this.successPv = 0;
		this.giveUpPv = 0;
		this.parseErrorPv = 0;
		this.invalidPv = 0;
		this.failPv = 0;
		this.actualRate = BigDecimal.valueOf(-1);
		this.competeRate = BigDecimal.valueOf(-1);
		this.successRate = BigDecimal.valueOf(-1);
		this.overtimeRate = BigDecimal.valueOf(-1);
		this.parseErrRate = BigDecimal.valueOf(-1);
	}

	/************************** GETTRT & SETTER**********************************/

	public void setActualRate(double actualRate) {
		this.actualRate = ReportUtil.doubleToBigDecimal(actualRate);
	}

	public void setCompeteRate(double competeRate) {
		this.competeRate = ReportUtil.doubleToBigDecimal(competeRate);
	}

	public void setSuccessRate(double successRate) {
		this.successRate = ReportUtil.doubleToBigDecimal(successRate);
	}

	public void setOvertimeRate(double overtimeRate) {
		this.overtimeRate = ReportUtil.doubleToBigDecimal(overtimeRate);
	}

	public void setParseErrRate(double parseErrRate) {
		this.parseErrRate = ReportUtil.doubleToBigDecimal(parseErrRate);
	}

	public BigDecimal getActualRate() {
		return actualRate;
	}

	public void setActualRate(BigDecimal actualRate) {
		this.actualRate = actualRate;
	}

	public BigDecimal getCompeteRate() {
		return competeRate;
	}

	public void setCompeteRate(BigDecimal competeRate) {
		this.competeRate = competeRate;
	}

	public BigDecimal getSuccessRate() {
		return successRate;
	}

	public void setSuccessRate(BigDecimal successRate) {
		this.successRate = successRate;
	}

	public BigDecimal getOvertimeRate() {
		return overtimeRate;
	}

	public void setOvertimeRate(BigDecimal overtimeRate) {
		this.overtimeRate = overtimeRate;
	}

	public BigDecimal getParseErrRate() {
		return parseErrRate;
	}

	public void setParseErrRate(BigDecimal parseErrRate) {
		this.parseErrRate = parseErrRate;
	}

	public String getShowDate() {
		return showDate;
	}

	public void setShowDate(String showDate) {
		this.showDate = showDate;
	}

	public long getAvailablePv() {
		return availablePv;
	}

	public void setAvailablePv(long availablePv) {
		this.availablePv = availablePv;
	}

	public long getActualPv() {
		return actualPv;
	}

	public void setActualPv(long actualPv) {
		this.actualPv = actualPv;
	}

	public long getCompetePv() {
		return competePv;
	}

	public void setCompetePv(long competePv) {
		this.competePv = competePv;
	}

	public long getSuccessPv() {
		return successPv;
	}

	public void setSuccessPv(long successPv) {
		this.successPv = successPv;
	}

	public long getGiveUpPv() {
		return giveUpPv;
	}

	public void setGiveUpPv(long giveUpPv) {
		this.giveUpPv = giveUpPv;
	}

	public long getParseErrorPv() {
		return parseErrorPv;
	}

	public void setParseErrorPv(long parseErrorPv) {
		this.parseErrorPv = parseErrorPv;
	}

	public long getInvalidPv() {
		return invalidPv;
	}

	public void setInvalidPv(long invalidPv) {
		this.invalidPv = invalidPv;
	}

	public long getFailPv() {
		return failPv;
	}

	public void setFailPv(long failPv) {
		this.failPv = failPv;
	}

	public long getOvertimePv() {
		return overtimePv;
	}

	public void setOvertimePv(long overtimePv) {
		this.overtimePv = overtimePv;
	}

}
