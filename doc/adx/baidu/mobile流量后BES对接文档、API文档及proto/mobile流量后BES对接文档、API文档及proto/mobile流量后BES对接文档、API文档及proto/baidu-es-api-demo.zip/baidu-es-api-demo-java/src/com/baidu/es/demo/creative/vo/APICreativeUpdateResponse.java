package com.baidu.es.demo.creative.vo;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.baidu.es.demo.common.vo.BaseResponse;

public class APICreativeUpdateResponse extends BaseResponse implements Serializable {

	private static final long serialVersionUID = -8868143479101779203L;
	
	private List<APICreative> response;

	public List<APICreative> getResponse() {
		return response;
	}

	public void setResponse(List<APICreative> response) {
		this.response = response;
	}
	
	public String toString(){
		return new ToStringBuilder(this, ToStringStyle.DEFAULT_STYLE)
		.append("status",status)
		.append("errors",errors)
		.append("response",response)
        .toString();
	}
	
}