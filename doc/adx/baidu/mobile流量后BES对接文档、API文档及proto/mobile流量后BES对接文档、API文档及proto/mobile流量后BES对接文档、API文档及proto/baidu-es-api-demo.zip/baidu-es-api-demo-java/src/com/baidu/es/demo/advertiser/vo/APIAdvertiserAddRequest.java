package com.baidu.es.demo.advertiser.vo;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.baidu.es.demo.common.vo.BaseRequest;

public class APIAdvertiserAddRequest extends BaseRequest implements Serializable{

	private static final long serialVersionUID = -4675701070857440506L;

	List<APIAdvertiser> request;

	public List<APIAdvertiser> getRequest() {
		return request;
	}

	public void setRequest(List<APIAdvertiser> request) {
		this.request = request;
	}
	
	public String toString(){
		return new ToStringBuilder(this, ToStringStyle.DEFAULT_STYLE)
		.append("authHeader",authHeader)
		.append("request",request)
        .toString();
	}

}
