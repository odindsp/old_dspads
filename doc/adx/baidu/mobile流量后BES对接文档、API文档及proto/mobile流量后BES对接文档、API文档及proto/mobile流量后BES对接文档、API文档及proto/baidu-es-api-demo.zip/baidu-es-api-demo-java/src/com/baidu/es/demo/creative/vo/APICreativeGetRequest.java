package com.baidu.es.demo.creative.vo;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.baidu.es.demo.common.vo.BaseRequest;

public class APICreativeGetRequest extends BaseRequest implements Serializable {

	private static final long serialVersionUID = -2343946895763933471L;

	private List<Long> creativeIds;

	public List<Long> getCreativeIds() {
		return creativeIds;
	}

	public void setCreativeIds(List<Long> creativeIds) {
		this.creativeIds = creativeIds;
	}
	
	public String toString(){
		return new ToStringBuilder(this, ToStringStyle.DEFAULT_STYLE)
		.append("authHeader",authHeader)
		.append("creativeIds",creativeIds)
        .toString();
	}

}
