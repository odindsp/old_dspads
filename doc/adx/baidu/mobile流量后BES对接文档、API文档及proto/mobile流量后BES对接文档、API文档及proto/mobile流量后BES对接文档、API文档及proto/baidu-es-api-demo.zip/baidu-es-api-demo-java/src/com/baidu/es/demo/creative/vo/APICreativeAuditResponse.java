package com.baidu.es.demo.creative.vo;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.baidu.es.demo.common.vo.BaseResponse;

public class APICreativeAuditResponse extends BaseResponse implements Serializable {

	private static final long serialVersionUID = -6226226595436014584L;

	private List<APICreativeAudit> response;

	public List<APICreativeAudit> getResponse() {
		return response;
	}

	public void setResponse(List<APICreativeAudit> response) {
		this.response = response;
	}

	public String toString(){
		return new ToStringBuilder(this, ToStringStyle.DEFAULT_STYLE)
		.append("status",status)
		.append("errors",errors)
		.append("response",response)
        .toString();
	}
	
}
