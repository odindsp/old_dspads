package com.baidu.es.demo.advertiser.vo;

import java.io.Serializable;

public class APIAdvertiser implements Serializable {

	private static final long serialVersionUID = 9131158642127107715L;

	private long advertiserId;

	private String advertiserName;

	public long getAdvertiserId() {
		return advertiserId;
	}

	public void setAdvertiserId(long advertiserId) {
		this.advertiserId = advertiserId;
	}

	public String getAdvertiserName() {
		return advertiserName;
	}

	public void setAdvertiserName(String advertiserName) {
		this.advertiserName = advertiserName;
	}

}
