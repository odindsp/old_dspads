package com.baidu.es.demo.report.vo;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.baidu.es.demo.common.vo.BaseResponse;

public class APIReportRtbResponse extends BaseResponse implements Serializable{

	private static final long serialVersionUID = -8892330674259966068L;

	private List<MonitorItem> response;

	public List<MonitorItem> getResponse() {
		return response;
	}

	public void setResponse(List<MonitorItem> response) {
		this.response = response;
	}
	
	public String toString(){
		return new ToStringBuilder(this, ToStringStyle.DEFAULT_STYLE)
		.append("status",status)
		.append("errors",errors)
		.append("response",response)
        .toString();
	}
	
}
