package com.baidu.es.demo.common;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.util.EntityUtils;

import com.baidu.es.demo.common.constant.BaiduEsConstant;
import com.baidu.es.demo.common.vo.AuthRequest;
import com.baidu.es.demo.util.JsonUtils;

public class BaseHTTP {

	private static final Log log = LogFactory.getLog(BaseHTTP.class);

	public static <T> void post(String url, T request) {
		HttpPost httpost = new HttpPost(url);

		httpost.setHeader("Content-Type", BaiduEsConstant.CONTENT_TYPE);
		httpost.setHeader("Accept", BaiduEsConstant.ACCEPT);

		log.info("REQUEST URL:\n" + url);
		try {
			String requestBody = JsonUtils.toJson(request);
			log.info("REQUEST:\n" + requestBody);
			StringEntity input = new StringEntity(requestBody, "UTF-8");
			input.setContentType(BaiduEsConstant.CONTENT_TYPE);
			httpost.setEntity(input);

			DefaultHttpClient httpclient = getHttpClient(true);
			HttpResponse response = httpclient.execute(httpost);

			HttpEntity entity = response.getEntity();
			String body = EntityUtils.toString(entity);
			log.info("RESPONSE:\n" + body);

		} catch (UnsupportedEncodingException e) {
			log.error(e.getMessage(), e);
		} catch (ParseException e) {
			log.error(e.getMessage(), e);
		} catch (ClientProtocolException e) {
			log.error(e.getMessage(), e);
		} catch (IOException e) {
			log.error(e.getMessage(), e);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		} finally {
			try {
				httpost.releaseConnection();
			} catch (Exception e) {
				log.error(e.getMessage(), e);
			}
		}
	}

	@SuppressWarnings({ "deprecation" })
	private static DefaultHttpClient getHttpClient(boolean isSSL) throws Exception {
		DefaultHttpClient httpclient = new DefaultHttpClient();
		httpclient.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT, 20000);
		if (isSSL) {
			SSLContext ctx = SSLContext.getInstance("TLS");
			X509TrustManager tm = new X509TrustManager() {
				public void checkClientTrusted(X509Certificate[] xcs, String string) throws CertificateException {
				}

				public void checkServerTrusted(X509Certificate[] xcs, String string) throws CertificateException {
				}

				public X509Certificate[] getAcceptedIssuers() {
					return null;
				}
			};
			ctx.init(null, new TrustManager[] { tm }, null);
			SSLSocketFactory ssf = new SSLSocketFactory(ctx);
			ssf.setHostnameVerifier(SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
			ClientConnectionManager ccm = httpclient.getConnectionManager();
			SchemeRegistry sr = ccm.getSchemeRegistry();
			sr.register(new Scheme("https", ssf, 443));
			httpclient = new DefaultHttpClient(ccm, httpclient.getParams());
			return httpclient;
		} else {
			return httpclient;
		}
	}

	protected AuthRequest getAuthHeader() {
		AuthRequest auth = new AuthRequest();
		auth.setDspId(BaiduEsConstant.DSPID);
		auth.setToken(BaiduEsConstant.TOKEN);
		return auth;
	}

}
