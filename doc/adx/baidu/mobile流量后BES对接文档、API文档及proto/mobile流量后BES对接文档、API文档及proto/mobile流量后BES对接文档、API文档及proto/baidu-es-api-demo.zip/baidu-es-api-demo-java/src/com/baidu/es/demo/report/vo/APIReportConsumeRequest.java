package com.baidu.es.demo.report.vo;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.baidu.es.demo.common.vo.BaseRequest;

public class APIReportConsumeRequest extends BaseRequest implements Serializable{

	private static final long serialVersionUID = 6147524161065046120L;

	private String startDate;

	private String endDate;

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	
	public String toString(){
		return new ToStringBuilder(this, ToStringStyle.DEFAULT_STYLE)
		.append("authHeader",authHeader)
		.append("startDate",startDate)
		.append("endDate",endDate)
        .toString();
	}
	
}
