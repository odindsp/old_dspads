
#define TEST_DRIVER
#ifdef TEST_DRIVER

#include "price.h"

int main(void)
{
    char* dec_key="7183e751829e457488a8f9e13cdb1292";
    char* sign_key = "b4056881520040a0af16fdccb99d68bb";
    char* src="JR9YVr-YW3HcCETOOcw5nA";
    double price = price_decode(dec_key,sign_key,src);
    printf("price %f\n",price);
    return 0;
}

#endif