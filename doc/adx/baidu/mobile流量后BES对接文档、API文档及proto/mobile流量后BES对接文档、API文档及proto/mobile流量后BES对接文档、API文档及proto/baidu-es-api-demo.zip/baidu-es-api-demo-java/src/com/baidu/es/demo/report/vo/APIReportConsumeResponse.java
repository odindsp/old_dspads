package com.baidu.es.demo.report.vo;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.baidu.es.demo.common.vo.BaseResponse;

public class APIReportConsumeResponse extends BaseResponse implements Serializable{

	private static final long serialVersionUID = 3900494882812528711L;

	private List<StatDayItem> response;

	public List<StatDayItem> getResponse() {
		return response;
	}

	public void setResponse(List<StatDayItem> response) {
		this.response = response;
	}
	
	public String toString(){
		return new ToStringBuilder(this, ToStringStyle.DEFAULT_STYLE)
		.append("status",status)
		.append("errors",errors)
		.append("response",response)
        .toString();
	}
	
}
